﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class clientslist
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(13, 85)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1233, 460)
        Me.DataGridView1.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cooper Black", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 34)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Clients Lists"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightCyan
        Me.Button2.Image = Global.CarRental.My.Resources.Resources.check
        Me.Button2.Location = New System.Drawing.Point(483, 14)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(77, 65)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Refresh"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightCyan
        Me.Button1.Image = Global.CarRental.My.Resources.Resources.back
        Me.Button1.Location = New System.Drawing.Point(401, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 66)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Back"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.LightCyan
        Me.Button17.Image = Global.CarRental.My.Resources.Resources.Add2
        Me.Button17.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button17.Location = New System.Drawing.Point(1138, 12)
        Me.Button17.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(62, 63)
        Me.Button17.TabIndex = 16
        Me.Button17.Text = "Add"
        Me.Button17.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Button8.Image = Global.CarRental.My.Resources.Resources.Add2
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button8.Location = New System.Drawing.Point(1591, 14)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(62, 63)
        Me.Button8.TabIndex = 16
        Me.Button8.Text = "Add"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.LightCyan
        Me.Button15.Image = Global.CarRental.My.Resources.Resources.edit32
        Me.Button15.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button15.Location = New System.Drawing.Point(1044, 12)
        Me.Button15.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(72, 63)
        Me.Button15.TabIndex = 15
        Me.Button15.Text = "Edit"
        Me.Button15.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.DarkTurquoise
        Me.Button7.Image = Global.CarRental.My.Resources.Resources.edit32
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button7.Location = New System.Drawing.Point(1394, 14)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(72, 63)
        Me.Button7.TabIndex = 15
        Me.Button7.Text = "Edit"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.LightCyan
        Me.Button12.Image = Global.CarRental.My.Resources.Resources.trash32
        Me.Button12.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button12.Location = New System.Drawing.Point(953, 12)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(71, 63)
        Me.Button12.TabIndex = 14
        Me.Button12.Text = "Delete"
        Me.Button12.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.LightCyan
        Me.Button11.Image = Global.CarRental.My.Resources.Resources.zoom_48_hot
        Me.Button11.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button11.Location = New System.Drawing.Point(862, 12)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(70, 65)
        Me.Button11.TabIndex = 13
        Me.Button11.Text = "Search"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.LightCyan
        Me.Button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button10.Image = Global.CarRental.My.Resources.Resources.credit_card
        Me.Button10.Location = New System.Drawing.Point(775, 12)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(68, 65)
        Me.Button10.TabIndex = 11
        Me.Button10.Text = "Credit Cards"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.LightCyan
        Me.Button9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button9.Image = Global.CarRental.My.Resources.Resources.Credit_Card1
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button9.Location = New System.Drawing.Point(669, 12)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(76, 65)
        Me.Button9.TabIndex = 10
        Me.Button9.Text = "Insurance Cards"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.LightCyan
        Me.Button4.Image = Global.CarRental.My.Resources.Resources.close321
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button4.Location = New System.Drawing.Point(567, 12)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(80, 66)
        Me.Button4.TabIndex = 9
        Me.Button4.Text = "Exit"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.Color.LightCyan
        Me.Button22.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Image = Global.CarRental.My.Resources.Resources.back
        Me.Button22.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button22.Location = New System.Drawing.Point(104, 562)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(82, 65)
        Me.Button22.TabIndex = 24
        Me.Button22.Text = "Rollback"
        Me.Button22.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.Color.LightCyan
        Me.Button21.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.Image = Global.CarRental.My.Resources.Resources.accept32
        Me.Button21.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button21.Location = New System.Drawing.Point(11, 562)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(87, 65)
        Me.Button21.TabIndex = 21
        Me.Button21.Text = "Commit"
        Me.Button21.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LightCyan
        Me.Button3.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = Global.CarRental.My.Resources.Resources.USB_drive___dark
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button3.Location = New System.Drawing.Point(483, 562)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(93, 65)
        Me.Button3.TabIndex = 23
        Me.Button3.Text = "RESTORE"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.LightCyan
        Me.Button5.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Image = Global.CarRental.My.Resources.Resources.USB_drive1
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button5.Location = New System.Drawing.Point(369, 562)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(90, 66)
        Me.Button5.TabIndex = 22
        Me.Button5.Text = "BACKUP"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button5.UseVisualStyleBackColor = False
        '
        'clientslist
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(1259, 649)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button4)
        Me.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "clientslist"
        Me.Text = "clientslist"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
End Class
