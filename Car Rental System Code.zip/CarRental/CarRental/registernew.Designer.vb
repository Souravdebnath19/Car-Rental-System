﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class registernew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lbl = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.txtpassport = New System.Windows.Forms.TextBox()
        Me.txthomephone = New System.Windows.Forms.TextBox()
        Me.txthomeadd = New System.Windows.Forms.TextBox()
        Me.txtlicense = New System.Windows.Forms.TextBox()
        Me.txtemail = New System.Windows.Forms.TextBox()
        Me.txtlocalphone = New System.Windows.Forms.TextBox()
        Me.txtlocaladd = New System.Windows.Forms.TextBox()
        Me.txtpob = New System.Windows.Forms.TextBox()
        Me.txtcompany = New System.Windows.Forms.TextBox()
        Me.txtlname = New System.Windows.Forms.TextBox()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(665, 114)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(76, 22)
        Me.TextBox1.TabIndex = 44
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(508, 114)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(96, 23)
        Me.ComboBox2.TabIndex = 43
        '
        'ComboBox1
        '
        Me.ComboBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(610, 114)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(49, 23)
        Me.ComboBox1.TabIndex = 42
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Cooper Black", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label14.Location = New System.Drawing.Point(549, 89)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(97, 14)
        Me.Label14.TabIndex = 41
        Me.Label14.Text = "DD/MM/YYYY"
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.BackColor = System.Drawing.Color.Transparent
        Me.lbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lbl.Location = New System.Drawing.Point(420, 397)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(0, 15)
        Me.lbl.TabIndex = 40
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Location = New System.Drawing.Point(413, 396)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(0, 15)
        Me.Label13.TabIndex = 39
        '
        'ProgressBar1
        '
        Me.ProgressBar1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ProgressBar1.Location = New System.Drawing.Point(34, 421)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(475, 23)
        Me.ProgressBar1.TabIndex = 38
        Me.ProgressBar1.Visible = False
        '
        'txtpassport
        '
        Me.txtpassport.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtpassport.Location = New System.Drawing.Point(508, 236)
        Me.txtpassport.Name = "txtpassport"
        Me.txtpassport.Size = New System.Drawing.Size(187, 22)
        Me.txtpassport.TabIndex = 34
        '
        'txthomephone
        '
        Me.txthomephone.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txthomephone.Location = New System.Drawing.Point(508, 196)
        Me.txthomephone.Name = "txthomephone"
        Me.txthomephone.Size = New System.Drawing.Size(187, 22)
        Me.txthomephone.TabIndex = 33
        '
        'txthomeadd
        '
        Me.txthomeadd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txthomeadd.Location = New System.Drawing.Point(508, 153)
        Me.txthomeadd.Name = "txthomeadd"
        Me.txthomeadd.Size = New System.Drawing.Size(187, 22)
        Me.txthomeadd.TabIndex = 32
        '
        'txtlicense
        '
        Me.txtlicense.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlicense.Location = New System.Drawing.Point(172, 359)
        Me.txtlicense.Name = "txtlicense"
        Me.txtlicense.Size = New System.Drawing.Size(187, 22)
        Me.txtlicense.TabIndex = 31
        '
        'txtemail
        '
        Me.txtemail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtemail.Location = New System.Drawing.Point(172, 306)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(187, 22)
        Me.txtemail.TabIndex = 30
        '
        'txtlocalphone
        '
        Me.txtlocalphone.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlocalphone.Location = New System.Drawing.Point(172, 253)
        Me.txtlocalphone.Name = "txtlocalphone"
        Me.txtlocalphone.Size = New System.Drawing.Size(187, 22)
        Me.txtlocalphone.TabIndex = 29
        '
        'txtlocaladd
        '
        Me.txtlocaladd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlocaladd.Location = New System.Drawing.Point(172, 200)
        Me.txtlocaladd.Name = "txtlocaladd"
        Me.txtlocaladd.Size = New System.Drawing.Size(187, 22)
        Me.txtlocaladd.TabIndex = 35
        '
        'txtpob
        '
        Me.txtpob.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtpob.Location = New System.Drawing.Point(172, 150)
        Me.txtpob.Name = "txtpob"
        Me.txtpob.Size = New System.Drawing.Size(187, 22)
        Me.txtpob.TabIndex = 28
        '
        'txtcompany
        '
        Me.txtcompany.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtcompany.Location = New System.Drawing.Point(172, 103)
        Me.txtcompany.Name = "txtcompany"
        Me.txtcompany.Size = New System.Drawing.Size(187, 22)
        Me.txtcompany.TabIndex = 24
        '
        'txtlname
        '
        Me.txtlname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtlname.Location = New System.Drawing.Point(508, 32)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(187, 22)
        Me.txtlname.TabIndex = 27
        '
        'txtid
        '
        Me.txtid.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtid.Location = New System.Drawing.Point(172, 17)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(187, 22)
        Me.txtid.TabIndex = 26
        '
        'txtname
        '
        Me.txtname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtname.Location = New System.Drawing.Point(172, 57)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(187, 22)
        Me.txtname.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(393, 243)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 15)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Passport ID:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Location = New System.Drawing.Point(34, 367)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 15)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "License ID:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(34, 314)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 15)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Email:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(393, 207)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(94, 15)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Home Phone:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(34, 256)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 15)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Local Phone:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(389, 157)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 15)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Home Address:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(34, 203)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(103, 15)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Local Address:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(37, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 15)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Place of Birth:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(389, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 15)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Date of Birth:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(37, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 15)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Company Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(389, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 15)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Last  Name:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label15.Location = New System.Drawing.Point(37, 17)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(68, 15)
        Me.Label15.TabIndex = 23
        Me.Label15.Text = "Client ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(37, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 15)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "First Name:"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = Global.CarRental.My.Resources.Resources.back
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(568, 402)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(173, 52)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "BACK"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Cooper Black", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = Global.CarRental.My.Resources.Resources.check
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(568, 346)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(173, 52)
        Me.Button1.TabIndex = 45
        Me.Button1.Text = "REGISTER"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label16.Location = New System.Drawing.Point(393, 314)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 15)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Password:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label17.Location = New System.Drawing.Point(393, 284)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(78, 15)
        Me.Label17.TabIndex = 12
        Me.Label17.Text = "Username:"
        '
        'txtusername
        '
        Me.txtusername.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtusername.Location = New System.Drawing.Point(508, 277)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(187, 22)
        Me.txtusername.TabIndex = 34
        '
        'txtpassword
        '
        Me.txtpassword.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtpassword.Location = New System.Drawing.Point(508, 313)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(187, 22)
        Me.txtpassword.TabIndex = 34
        '
        'registernew
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(802, 466)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.txtusername)
        Me.Controls.Add(Me.txtpassport)
        Me.Controls.Add(Me.txthomephone)
        Me.Controls.Add(Me.txthomeadd)
        Me.Controls.Add(Me.txtlicense)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.txtlocalphone)
        Me.Controls.Add(Me.txtlocaladd)
        Me.Controls.Add(Me.txtpob)
        Me.Controls.Add(Me.txtcompany)
        Me.Controls.Add(Me.txtlname)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "registernew"
        Me.Text = "registernew"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lbl As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtpassport As System.Windows.Forms.TextBox
    Friend WithEvents txthomephone As System.Windows.Forms.TextBox
    Friend WithEvents txthomeadd As System.Windows.Forms.TextBox
    Friend WithEvents txtlicense As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtlocalphone As System.Windows.Forms.TextBox
    Friend WithEvents txtlocaladd As System.Windows.Forms.TextBox
    Friend WithEvents txtpob As System.Windows.Forms.TextBox
    Friend WithEvents txtcompany As System.Windows.Forms.TextBox
    Friend WithEvents txtlname As System.Windows.Forms.TextBox
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtusername As System.Windows.Forms.TextBox
    Friend WithEvents txtpassword As System.Windows.Forms.TextBox
End Class
