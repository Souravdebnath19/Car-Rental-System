﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class myaccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblfname = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblcompany = New System.Windows.Forms.Label()
        Me.lbllname = New System.Windows.Forms.Label()
        Me.lbldob = New System.Windows.Forms.Label()
        Me.lblpob = New System.Windows.Forms.Label()
        Me.lblhomeadd = New System.Windows.Forms.Label()
        Me.lbllocaladd = New System.Windows.Forms.Label()
        Me.lblemail = New System.Windows.Forms.Label()
        Me.lblpassport = New System.Windows.Forms.Label()
        Me.lbllicense = New System.Windows.Forms.Label()
        Me.lblhomephone = New System.Windows.Forms.Label()
        Me.lbllocalphone = New System.Windows.Forms.Label()
        Me.lblusername = New System.Windows.Forms.Label()
        Me.lblclientid = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblusername)
        Me.GroupBox1.Controls.Add(Me.lbllocalphone)
        Me.GroupBox1.Controls.Add(Me.lblhomephone)
        Me.GroupBox1.Controls.Add(Me.lbllicense)
        Me.GroupBox1.Controls.Add(Me.lblpassport)
        Me.GroupBox1.Controls.Add(Me.lblemail)
        Me.GroupBox1.Controls.Add(Me.lbllocaladd)
        Me.GroupBox1.Controls.Add(Me.lblhomeadd)
        Me.GroupBox1.Controls.Add(Me.lblpob)
        Me.GroupBox1.Controls.Add(Me.lbldob)
        Me.GroupBox1.Controls.Add(Me.lbllname)
        Me.GroupBox1.Controls.Add(Me.lblcompany)
        Me.GroupBox1.Controls.Add(Me.lblfname)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(226, 13)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(809, 501)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 31)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(382, 31)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 21)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Last Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 79)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(168, 21)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Company Name:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(32, 124)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(143, 21)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Date of Birth:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(382, 124)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(149, 21)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Place of Birth:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(32, 184)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(153, 21)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Home Address:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(35, 227)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(150, 21)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Local Address:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(32, 280)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 21)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Email:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(375, 280)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(129, 21)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Passport ID:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(32, 324)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(115, 21)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "License ID:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(32, 440)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(134, 21)
        Me.Label11.TabIndex = 9
        Me.Label11.Text = "USERNAME:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(32, 376)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(135, 21)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "Home Phone:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(375, 376)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(132, 21)
        Me.Label13.TabIndex = 11
        Me.Label13.Text = "Local Phone:"
        '
        'lblfname
        '
        Me.lblfname.AutoSize = True
        Me.lblfname.ForeColor = System.Drawing.Color.Blue
        Me.lblfname.Location = New System.Drawing.Point(164, 31)
        Me.lblfname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblfname.Name = "lblfname"
        Me.lblfname.Size = New System.Drawing.Size(124, 21)
        Me.lblfname.TabIndex = 12
        Me.lblfname.Text = "First Name:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(86, 240)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 21)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "ID"
        '
        'lblcompany
        '
        Me.lblcompany.AutoSize = True
        Me.lblcompany.ForeColor = System.Drawing.Color.Blue
        Me.lblcompany.Location = New System.Drawing.Point(198, 79)
        Me.lblcompany.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblcompany.Name = "lblcompany"
        Me.lblcompany.Size = New System.Drawing.Size(124, 21)
        Me.lblcompany.TabIndex = 13
        Me.lblcompany.Text = "First Name:"
        '
        'lbllname
        '
        Me.lbllname.AutoSize = True
        Me.lbllname.ForeColor = System.Drawing.Color.Blue
        Me.lbllname.Location = New System.Drawing.Point(496, 31)
        Me.lbllname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbllname.Name = "lbllname"
        Me.lbllname.Size = New System.Drawing.Size(124, 21)
        Me.lbllname.TabIndex = 14
        Me.lbllname.Text = "First Name:"
        '
        'lbldob
        '
        Me.lbldob.AutoSize = True
        Me.lbldob.ForeColor = System.Drawing.Color.Blue
        Me.lbldob.Location = New System.Drawing.Point(183, 124)
        Me.lbldob.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbldob.Name = "lbldob"
        Me.lbldob.Size = New System.Drawing.Size(124, 21)
        Me.lbldob.TabIndex = 15
        Me.lbldob.Text = "First Name:"
        '
        'lblpob
        '
        Me.lblpob.AutoSize = True
        Me.lblpob.ForeColor = System.Drawing.Color.Blue
        Me.lblpob.Location = New System.Drawing.Point(527, 124)
        Me.lblpob.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblpob.Name = "lblpob"
        Me.lblpob.Size = New System.Drawing.Size(124, 21)
        Me.lblpob.TabIndex = 16
        Me.lblpob.Text = "First Name:"
        '
        'lblhomeadd
        '
        Me.lblhomeadd.AutoSize = True
        Me.lblhomeadd.ForeColor = System.Drawing.Color.Blue
        Me.lblhomeadd.Location = New System.Drawing.Point(183, 184)
        Me.lblhomeadd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblhomeadd.Name = "lblhomeadd"
        Me.lblhomeadd.Size = New System.Drawing.Size(124, 21)
        Me.lblhomeadd.TabIndex = 17
        Me.lblhomeadd.Text = "First Name:"
        '
        'lbllocaladd
        '
        Me.lbllocaladd.AutoSize = True
        Me.lbllocaladd.ForeColor = System.Drawing.Color.Blue
        Me.lbllocaladd.Location = New System.Drawing.Point(183, 227)
        Me.lbllocaladd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbllocaladd.Name = "lbllocaladd"
        Me.lbllocaladd.Size = New System.Drawing.Size(124, 21)
        Me.lbllocaladd.TabIndex = 18
        Me.lbllocaladd.Text = "First Name:"
        '
        'lblemail
        '
        Me.lblemail.AutoSize = True
        Me.lblemail.ForeColor = System.Drawing.Color.Blue
        Me.lblemail.Location = New System.Drawing.Point(112, 280)
        Me.lblemail.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblemail.Name = "lblemail"
        Me.lblemail.Size = New System.Drawing.Size(124, 21)
        Me.lblemail.TabIndex = 19
        Me.lblemail.Text = "First Name:"
        '
        'lblpassport
        '
        Me.lblpassport.AutoSize = True
        Me.lblpassport.ForeColor = System.Drawing.Color.Blue
        Me.lblpassport.Location = New System.Drawing.Point(496, 280)
        Me.lblpassport.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblpassport.Name = "lblpassport"
        Me.lblpassport.Size = New System.Drawing.Size(124, 21)
        Me.lblpassport.TabIndex = 20
        Me.lblpassport.Text = "First Name:"
        '
        'lbllicense
        '
        Me.lbllicense.AutoSize = True
        Me.lbllicense.ForeColor = System.Drawing.Color.Blue
        Me.lbllicense.Location = New System.Drawing.Point(146, 324)
        Me.lbllicense.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbllicense.Name = "lbllicense"
        Me.lbllicense.Size = New System.Drawing.Size(124, 21)
        Me.lbllicense.TabIndex = 21
        Me.lbllicense.Text = "First Name:"
        '
        'lblhomephone
        '
        Me.lblhomephone.AutoSize = True
        Me.lblhomephone.ForeColor = System.Drawing.Color.Blue
        Me.lblhomephone.Location = New System.Drawing.Point(164, 376)
        Me.lblhomephone.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblhomephone.Name = "lblhomephone"
        Me.lblhomephone.Size = New System.Drawing.Size(124, 21)
        Me.lblhomephone.TabIndex = 22
        Me.lblhomephone.Text = "First Name:"
        '
        'lbllocalphone
        '
        Me.lbllocalphone.AutoSize = True
        Me.lbllocalphone.ForeColor = System.Drawing.Color.Blue
        Me.lbllocalphone.Location = New System.Drawing.Point(515, 376)
        Me.lbllocalphone.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbllocalphone.Name = "lbllocalphone"
        Me.lbllocalphone.Size = New System.Drawing.Size(124, 21)
        Me.lbllocalphone.TabIndex = 23
        Me.lbllocalphone.Text = "First Name:"
        '
        'lblusername
        '
        Me.lblusername.AutoSize = True
        Me.lblusername.Font = New System.Drawing.Font("Cooper Black", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusername.ForeColor = System.Drawing.Color.Blue
        Me.lblusername.Location = New System.Drawing.Point(174, 440)
        Me.lblusername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblusername.Name = "lblusername"
        Me.lblusername.Size = New System.Drawing.Size(133, 24)
        Me.lblusername.TabIndex = 24
        Me.lblusername.Text = "First Name:"
        '
        'lblclientid
        '
        Me.lblclientid.AutoSize = True
        Me.lblclientid.Font = New System.Drawing.Font("Cooper Black", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblclientid.ForeColor = System.Drawing.Color.Blue
        Me.lblclientid.Location = New System.Drawing.Point(86, 274)
        Me.lblclientid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblclientid.Name = "lblclientid"
        Me.lblclientid.Size = New System.Drawing.Size(62, 24)
        Me.lblclientid.TabIndex = 25
        Me.lblclientid.Text = "First"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.CarRental.My.Resources.Resources.m
        Me.PictureBox1.Location = New System.Drawing.Point(13, 27)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(192, 191)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightCyan
        Me.Button1.Image = Global.CarRental.My.Resources.Resources.back
        Me.Button1.Location = New System.Drawing.Point(9, 438)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 66)
        Me.Button1.TabIndex = 28
        Me.Button1.Text = "Back"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.LightCyan
        Me.Button15.Image = Global.CarRental.My.Resources.Resources.edit32
        Me.Button15.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button15.Location = New System.Drawing.Point(13, 351)
        Me.Button15.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(72, 63)
        Me.Button15.TabIndex = 27
        Me.Button15.Text = "Edit"
        Me.Button15.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.LightCyan
        Me.Button4.Image = Global.CarRental.My.Resources.Resources.close321
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button4.Location = New System.Drawing.Point(92, 438)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(80, 66)
        Me.Button4.TabIndex = 26
        Me.Button4.Text = "Exit"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightCyan
        Me.Button2.Font = New System.Drawing.Font("Cooper Black", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = Global.CarRental.My.Resources.Resources.check
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button2.Location = New System.Drawing.Point(95, 351)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(77, 65)
        Me.Button2.TabIndex = 29
        Me.Button2.Text = "Refresh"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = False
        '
        'myaccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1048, 527)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.lblclientid)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Cooper Black", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.Name = "myaccount"
        Me.Text = "myaccount"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblusername As System.Windows.Forms.Label
    Friend WithEvents lbllocalphone As System.Windows.Forms.Label
    Friend WithEvents lblhomephone As System.Windows.Forms.Label
    Friend WithEvents lbllicense As System.Windows.Forms.Label
    Friend WithEvents lblpassport As System.Windows.Forms.Label
    Friend WithEvents lblemail As System.Windows.Forms.Label
    Friend WithEvents lbllocaladd As System.Windows.Forms.Label
    Friend WithEvents lblhomeadd As System.Windows.Forms.Label
    Friend WithEvents lblpob As System.Windows.Forms.Label
    Friend WithEvents lbldob As System.Windows.Forms.Label
    Friend WithEvents lbllname As System.Windows.Forms.Label
    Friend WithEvents lblcompany As System.Windows.Forms.Label
    Friend WithEvents lblfname As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblclientid As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
